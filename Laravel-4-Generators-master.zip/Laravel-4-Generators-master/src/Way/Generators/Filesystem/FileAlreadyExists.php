<?php namespace Way\Generators\Filesystem;

class FileAlreadyExists extends \Exception {}